# Notebooks and Code for Advanced Portfolio Construction and Analysis with Python

(c) Vijay Vaidyanathan 2019

These files should be in the same level where you have your data folder.

Please send any comments, bugs (or bug fixes!) to vijay@OptimalAM.com and I'll incorporate in the next version.

This is the beta test version v02
